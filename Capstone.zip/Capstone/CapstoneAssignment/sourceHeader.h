#ifndef SOURCEHEADER_H
#define SOURCEHEADER_H

#include <iostream>
#include <string>
#include <stdexcept>
#include <ctime>

using namespace std;

class Drama {
public:
    string genre;
    int numEpisodes;
    string streamingPlatform;

    // Constructors
    Drama();
    Drama(string Genre, int NumEpisodes, string StreamingPlatform);

    // Abstract Data Type
    virtual void displayInfo() const;

    // Destructor
    virtual ~Drama();
};

// Inheritance
class KayDrama : public Drama {
public:
    KayDrama(string Genre, int NumEpisodes, string StreamingPlatform);

    void displayInfo() const override;

    // Destructor
    ~KayDrama() override;
};

Drama recommendDrama(string genre, int maxNumEpisodes, string leadActorActress, string streamingPlatform);

#endif  
