#include <iostream>
#include <string>
#include <ctime>
#include "sourceHeader.h"
using namespace std;

// Constructor
Drama::Drama() {
    genre = "DEFAULT";
    numEpisodes = 0;
    streamingPlatform = "DEFAULT";
}

// Constructor
Drama::Drama(string Genre, int NumEpisodes, string StreamingPlatform) {
    genre = Genre;
    numEpisodes = NumEpisodes;
    streamingPlatform = StreamingPlatform;
}

void Drama::displayInfo() const {
    cout << genre << ", " << numEpisodes << " episodes, " << streamingPlatform << endl;
}

// Destructor
Drama::~Drama() {}

KayDrama::KayDrama(string Genre, int NumEpisodes, string StreamingPlatform) {
    genre = Genre;
    numEpisodes = NumEpisodes;
    streamingPlatform = StreamingPlatform;
}

void KayDrama::displayInfo() const {
    cout << "K Dramas are : ";
    Drama::displayInfo();
}

// Destructor
KayDrama::~KayDrama() {}

Drama recommendDrama(string genre, int maxEpisodes, string leadActorActress, string streamingPlatform) {
    Drama dramas[] = {
        {"Signal", 16, "Netflix"},
        {"Healer", 20, "Viki"},
        {"Hospital Playlist", 12, "Netflix"},
        {"VegaBond", 16, "Netflix"},
        {"Kingdom", 12, "Netflix"},
        {"Ashin Of North", 1, "Netflix"},
        {"Goblin", 16, "Netflix"},
        {"Hotel Del Luna", 16, "Viki"},
        {"W", 16, "Viki"},
        {"The King: Enteral Monarch", 16, "Netfilx"}
    };


    // Exception
    if (maxEpisodes <= 0) {
        throw invalid_argument("Maximum number of episodes cannot be less than or equal to 0.");
    }

    int randINDEX = rand() % sizeof(dramas) / sizeof(Drama);
    return dramas[randINDEX];
}

int main() {
    srand(time(0));

        string genre;
        int maxEpisodes;
        string leadActors;
        string streamingPlatform;

        cout << "Enter your preferred genre (e.g.: 'Romance', 'Fantasy', 'Drama', 'Historical', 'Action' or 'Thriller'): ";
        cin >> genre;
        cout << "Enter the maximum number of episodes: ";
        cin >> maxEpisodes;


        // Exception
        if (cin.fail()) {
            throw invalid_argument("Invalid input ! ");
        }

        cout << "Enter your preferred lead actor/actress (or 'Any' for any lead): ";
        cin >> leadActors;
        cout << "Enter your preferred streaming platform (e.g.: 'Netflix', 'Viki' or 'Any' for any platform) : ";
        cin >> streamingPlatform;


        // Exception
        if (cin.fail()) {
            throw invalid_argument("Invalid input ! ");
        }

        // Pointer
        Drama* dramaPtr = new Drama(recommendDrama(genre, maxEpisodes, leadActors, streamingPlatform));
        cout << "Recommended Dramas:" << endl;
        dramaPtr->displayInfo();

        delete dramaPtr;
    
    return 0;
}
